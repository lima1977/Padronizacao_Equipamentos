﻿namespace DatagridViewCRUD
{
	partial class frmSudentAdd
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSudentAdd));
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.linkLabel5 = new System.Windows.Forms.LinkLabel();
			this.btnSave = new System.Windows.Forms.Button();
			this.txtphone = new System.Windows.Forms.TextBox();
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtstdName = new System.Windows.Forms.TextBox();
			this.linkLabel2 = new System.Windows.Forms.LinkLabel();
			this.txtStudentID = new System.Windows.Forms.TextBox();
			this.btnCaptuer = new System.Windows.Forms.Button();
			this.pnlTop = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.btnBack = new System.Windows.Forms.PictureBox();
			this.linkLabel18 = new System.Windows.Forms.LinkLabel();
			this.linkLabel23 = new System.Windows.Forms.LinkLabel();
			this.lblAdminName = new System.Windows.Forms.LinkLabel();
			this.pnlMain = new System.Windows.Forms.Panel();
			this.picImage = new System.Windows.Forms.PictureBox();
			this.pnlTop.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.btnBack)).BeginInit();
			this.pnlMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
			this.SuspendLayout();
			// 
			// txtAddress
			// 
			this.txtAddress.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.txtAddress.Location = new System.Drawing.Point(14, 331);
			this.txtAddress.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtAddress.MaxLength = 100;
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.Size = new System.Drawing.Size(508, 59);
			this.txtAddress.TabIndex = 5;
			// 
			// linkLabel5
			// 
			this.linkLabel5.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel5.AllowDrop = true;
			this.linkLabel5.BackColor = System.Drawing.Color.Transparent;
			this.linkLabel5.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.linkLabel5.LinkArea = new System.Windows.Forms.LinkArea(0, 100);
			this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.linkLabel5.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel5.Location = new System.Drawing.Point(14, 284);
			this.linkLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.linkLabel5.Name = "linkLabel5";
			this.linkLabel5.Size = new System.Drawing.Size(192, 40);
			this.linkLabel5.TabIndex = 264;
			this.linkLabel5.TabStop = true;
			this.linkLabel5.Text = "Address";
			this.linkLabel5.UseCompatibleTextRendering = true;
			this.linkLabel5.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			// 
			// btnSave
			// 
			this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(176)))), ((int)(((byte)(30)))));
			this.btnSave.FlatAppearance.BorderSize = 0;
			this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnSave.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.btnSave.ForeColor = System.Drawing.Color.White;
			this.btnSave.Location = new System.Drawing.Point(544, 322);
			this.btnSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(132, 70);
			this.btnSave.TabIndex = 7;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = false;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// txtphone
			// 
			this.txtphone.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.txtphone.Location = new System.Drawing.Point(365, 240);
			this.txtphone.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtphone.MaxLength = 99;
			this.txtphone.Multiline = true;
			this.txtphone.Name = "txtphone";
			this.txtphone.Size = new System.Drawing.Size(311, 25);
			this.txtphone.TabIndex = 4;
			// 
			// txtEmail
			// 
			this.txtEmail.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.txtEmail.Location = new System.Drawing.Point(13, 240);
			this.txtEmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtEmail.MaxLength = 99;
			this.txtEmail.Multiline = true;
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(311, 25);
			this.txtEmail.TabIndex = 3;
			// 
			// txtstdName
			// 
			this.txtstdName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.txtstdName.Location = new System.Drawing.Point(365, 150);
			this.txtstdName.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtstdName.MaxLength = 99;
			this.txtstdName.Multiline = true;
			this.txtstdName.Name = "txtstdName";
			this.txtstdName.Size = new System.Drawing.Size(311, 25);
			this.txtstdName.TabIndex = 2;
			// 
			// linkLabel2
			// 
			this.linkLabel2.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel2.AllowDrop = true;
			this.linkLabel2.BackColor = System.Drawing.Color.Transparent;
			this.linkLabel2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.linkLabel2.LinkArea = new System.Windows.Forms.LinkArea(0, 100);
			this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.linkLabel2.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel2.Location = new System.Drawing.Point(365, 190);
			this.linkLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.linkLabel2.Name = "linkLabel2";
			this.linkLabel2.Size = new System.Drawing.Size(192, 40);
			this.linkLabel2.TabIndex = 254;
			this.linkLabel2.TabStop = true;
			this.linkLabel2.Text = "Phone";
			this.linkLabel2.UseCompatibleTextRendering = true;
			this.linkLabel2.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			// 
			// txtStudentID
			// 
			this.txtStudentID.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.txtStudentID.Location = new System.Drawing.Point(14, 150);
			this.txtStudentID.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.txtStudentID.MaxLength = 100;
			this.txtStudentID.Multiline = true;
			this.txtStudentID.Name = "txtStudentID";
			this.txtStudentID.ReadOnly = true;
			this.txtStudentID.Size = new System.Drawing.Size(311, 25);
			this.txtStudentID.TabIndex = 1;
			// 
			// btnCaptuer
			// 
			this.btnCaptuer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.btnCaptuer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCaptuer.FlatAppearance.BorderSize = 0;
			this.btnCaptuer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCaptuer.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Bold);
			this.btnCaptuer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(126)))), ((int)(((byte)(126)))));
			this.btnCaptuer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnCaptuer.Location = new System.Drawing.Point(695, 340);
			this.btnCaptuer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btnCaptuer.Name = "btnCaptuer";
			this.btnCaptuer.Size = new System.Drawing.Size(333, 50);
			this.btnCaptuer.TabIndex = 6;
			this.btnCaptuer.Text = "Upload Image";
			this.btnCaptuer.UseVisualStyleBackColor = false;
			this.btnCaptuer.Click += new System.EventHandler(this.btnCaptuer_Click);
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(158)))), ((int)(((byte)(204)))));
			this.pnlTop.Controls.Add(this.label1);
			this.pnlTop.Controls.Add(this.pictureBox1);
			this.pnlTop.Controls.Add(this.btnBack);
			this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlTop.Location = new System.Drawing.Point(0, 0);
			this.pnlTop.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1044, 60);
			this.pnlTop.TabIndex = 35;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Arial Narrow", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(83, 20);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(181, 24);
			this.label1.TabIndex = 15;
			this.label1.Text = "Student Details";
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.Image = global::DatagridViewCRUD.Properties.Resources.Student_3_64;
			this.pictureBox1.Location = new System.Drawing.Point(19, 10);
			this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(41, 45);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox1.TabIndex = 14;
			this.pictureBox1.TabStop = false;
			// 
			// btnBack
			// 
			this.btnBack.Image = global::DatagridViewCRUD.Properties.Resources.icon_back;
			this.btnBack.Location = new System.Drawing.Point(969, 12);
			this.btnBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.btnBack.Name = "btnBack";
			this.btnBack.Size = new System.Drawing.Size(45, 40);
			this.btnBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.btnBack.TabIndex = 0;
			this.btnBack.TabStop = false;
			this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
			// 
			// linkLabel18
			// 
			this.linkLabel18.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel18.AllowDrop = true;
			this.linkLabel18.BackColor = System.Drawing.Color.Transparent;
			this.linkLabel18.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.linkLabel18.LinkArea = new System.Windows.Forms.LinkArea(0, 100);
			this.linkLabel18.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.linkLabel18.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel18.Location = new System.Drawing.Point(23, 190);
			this.linkLabel18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.linkLabel18.Name = "linkLabel18";
			this.linkLabel18.Size = new System.Drawing.Size(192, 40);
			this.linkLabel18.TabIndex = 30;
			this.linkLabel18.TabStop = true;
			this.linkLabel18.Text = "Email";
			this.linkLabel18.UseCompatibleTextRendering = true;
			this.linkLabel18.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			// 
			// linkLabel23
			// 
			this.linkLabel23.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel23.AllowDrop = true;
			this.linkLabel23.BackColor = System.Drawing.Color.Transparent;
			this.linkLabel23.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.linkLabel23.LinkArea = new System.Windows.Forms.LinkArea(0, 100);
			this.linkLabel23.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.linkLabel23.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.linkLabel23.Location = new System.Drawing.Point(365, 100);
			this.linkLabel23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.linkLabel23.Name = "linkLabel23";
			this.linkLabel23.Size = new System.Drawing.Size(192, 40);
			this.linkLabel23.TabIndex = 25;
			this.linkLabel23.TabStop = true;
			this.linkLabel23.Text = "Student Name";
			this.linkLabel23.UseCompatibleTextRendering = true;
			this.linkLabel23.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			// 
			// lblAdminName
			// 
			this.lblAdminName.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.lblAdminName.AllowDrop = true;
			this.lblAdminName.BackColor = System.Drawing.Color.Transparent;
			this.lblAdminName.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
			this.lblAdminName.LinkArea = new System.Windows.Forms.LinkArea(0, 300);
			this.lblAdminName.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
			this.lblAdminName.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.lblAdminName.Location = new System.Drawing.Point(23, 100);
			this.lblAdminName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblAdminName.Name = "lblAdminName";
			this.lblAdminName.Size = new System.Drawing.Size(161, 40);
			this.lblAdminName.TabIndex = 10;
			this.lblAdminName.TabStop = true;
			this.lblAdminName.Text = "Student Id";
			this.lblAdminName.UseCompatibleTextRendering = true;
			this.lblAdminName.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			// 
			// pnlMain
			// 
			this.pnlMain.Controls.Add(this.txtAddress);
			this.pnlMain.Controls.Add(this.linkLabel5);
			this.pnlMain.Controls.Add(this.btnSave);
			this.pnlMain.Controls.Add(this.txtphone);
			this.pnlMain.Controls.Add(this.txtEmail);
			this.pnlMain.Controls.Add(this.txtstdName);
			this.pnlMain.Controls.Add(this.linkLabel2);
			this.pnlMain.Controls.Add(this.txtStudentID);
			this.pnlMain.Controls.Add(this.btnCaptuer);
			this.pnlMain.Controls.Add(this.pnlTop);
			this.pnlMain.Controls.Add(this.linkLabel18);
			this.pnlMain.Controls.Add(this.linkLabel23);
			this.pnlMain.Controls.Add(this.picImage);
			this.pnlMain.Controls.Add(this.lblAdminName);
			this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlMain.Location = new System.Drawing.Point(0, 0);
			this.pnlMain.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.pnlMain.Name = "pnlMain";
			this.pnlMain.Size = new System.Drawing.Size(1044, 410);
			this.pnlMain.TabIndex = 5;
			// 
			// picImage
			// 
			this.picImage.BackColor = System.Drawing.Color.LightGray;
			this.picImage.Location = new System.Drawing.Point(695, 70);
			this.picImage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
			this.picImage.Name = "picImage";
			this.picImage.Size = new System.Drawing.Size(329, 260);
			this.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.picImage.TabIndex = 23;
			this.picImage.TabStop = false;
			// 
			// frmSudentAdd
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.White;
			this.ClientSize = new System.Drawing.Size(1044, 410);
			this.Controls.Add(this.pnlMain);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSudentAdd";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Sudent Add /  Edit";
			this.Load += new System.EventHandler(this.frmSudentAdd_Load);
			this.pnlTop.ResumeLayout(false);
			this.pnlTop.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.btnBack)).EndInit();
			this.pnlMain.ResumeLayout(false);
			this.pnlMain.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TextBox txtAddress;
		private System.Windows.Forms.LinkLabel linkLabel5;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TextBox txtphone;
		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.TextBox txtstdName;
		private System.Windows.Forms.LinkLabel linkLabel2;
		private System.Windows.Forms.TextBox txtStudentID;
		private System.Windows.Forms.Button btnCaptuer;
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox btnBack;
		private System.Windows.Forms.LinkLabel linkLabel18;
		private System.Windows.Forms.LinkLabel linkLabel23;
		private System.Windows.Forms.PictureBox picImage;
		private System.Windows.Forms.LinkLabel lblAdminName;
		private System.Windows.Forms.Panel pnlMain;
	}
}